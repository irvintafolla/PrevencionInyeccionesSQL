import os
import requests

API_KEY = os.getenv("API_KEY")  # ✅ Obtiene la clave desde una variable de entorno

response = requests.get(f"https://api.secreta.com/data?key={API_KEY}")
print(response.json())
