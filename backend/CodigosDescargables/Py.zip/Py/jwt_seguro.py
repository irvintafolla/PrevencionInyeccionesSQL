from flask import Flask, request
import jwt

SECRET_KEY = "clave_secreta"

app = Flask(__name__)

@app.route("/api/usuario")
def obtener_usuario():
    token = request.args.get("token")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])  # ✅ Valida el token
        return f"Usuario autenticado: {payload['usuario']}"
    except jwt.ExpiredSignatureError:
        return "Token expirado.", 401
    except jwt.InvalidTokenError:
        return "Token inválido.", 401

app.run()
