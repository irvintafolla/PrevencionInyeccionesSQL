import bcrypt

contraseña = input("Ingrese su contraseña: ")  

# ✅ Hashea la contraseña antes de almacenarla
hashed = bcrypt.hashpw(contraseña.encode(), bcrypt.gensalt())

with open("passwords_hashed.txt", "wb") as file:
    file.write(hashed)
