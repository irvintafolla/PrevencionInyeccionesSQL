import pickle

class SecureUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        raise pickle.UnpicklingError("Deserialización bloqueada por seguridad")

data = input("Ingrese datos serializados: ")
unpickler = SecureUnpickler(data)
obj = unpickler.load()  # ✅ Restringe la carga de objetos desconocidos
print(obj)
