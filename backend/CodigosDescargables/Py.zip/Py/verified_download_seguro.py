import requests

url = input("Ingrese la URL del archivo: ")

dominios_permitidos = ["example.com", "github.com"]
if any(url.startswith(f"https://{dominio}") for dominio in dominios_permitidos):
    response = requests.get(url, stream=True)
    with open("archivo_descargado", "wb") as f:
        for chunk in response.iter_content(chunk_size=1024):
            f.write(chunk)
    print("Archivo descargado de fuente segura.")
else:
    print("Fuente no confiable. Descarga bloqueada.")
