from flask import Flask, request
import html

app = Flask(__name__)

@app.route("/comentarios")
def comentarios():
    comentario = request.args.get("comentario")
    comentario_limpio = html.escape(comentario)  # ✅ Sanitiza la entrada
    return f"<h1>{comentario_limpio}</h1>"

app.run()
