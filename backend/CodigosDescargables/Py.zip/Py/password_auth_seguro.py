import bcrypt

# Hashear la contraseña al registrarse
contraseña = b"admin123"
hashed = bcrypt.hashpw(contraseña, bcrypt.gensalt())

# Verificar la contraseña ingresada
contraseña_ingresada = input("Ingrese su contraseña: ").encode()
if bcrypt.checkpw(contraseña_ingresada, hashed):
    print("Acceso concedido")
else:
    print("Acceso denegado")
