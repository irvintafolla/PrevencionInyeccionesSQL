import socket
import hmac
import hashlib

SECRET_KEY = b"supersecreto"

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("127.0.0.1", 8080))  # ✅ Escucha solo en localhost
server.listen(5)

while True:
    client, _ = server.accept()
    challenge = b"auth"
    client.send(challenge)

    response = client.recv(1024)
    expected = hmac.new(SECRET_KEY, challenge, hashlib.sha256).digest()

    if hmac.compare_digest(response, expected):
        client.send(b"Autenticado")
    else:
        client.send(b"Acceso denegado")
    client.close()
