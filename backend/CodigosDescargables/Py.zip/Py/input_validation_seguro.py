import re

nombre = input("Ingrese su nombre: ")  

# ✅ Solo permite letras y espacios
if re.match(r"^[a-zA-Z ]+$", nombre):
    print(f"Bienvenido, {nombre}")
else:
    print("Nombre inválido. Solo se permiten letras y espacios.")
