import os

archivo = input("Ingrese el nombre del archivo: ")

directorio_seguro = "/home/user/seguro/"
ruta_completa = os.path.abspath(os.path.join(directorio_seguro, archivo))

if os.path.commonprefix([ruta_completa, directorio_seguro]) == directorio_seguro:
    with open(ruta_completa, "r") as f:
        print(f.read())
else:
    print("Acceso no permitido.")
