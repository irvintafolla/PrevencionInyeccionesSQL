import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.covariance import EllipticEnvelope

# Datos de entrenamiento
X = np.array([[1, 2], [2, 3], [3, 4], [1000, 1000]])
y = np.array([0, 0, 1, 1])

# ✅ Detecta y elimina datos anómalos antes de entrenar
detector = EllipticEnvelope(contamination=0.1)
detector.fit(X)
outliers = detector.predict(X) == 1
X_filtrado, y_filtrado = X[outliers], y[outliers]

modelo = LogisticRegression()
modelo.fit(X_filtrado, y_filtrado)
