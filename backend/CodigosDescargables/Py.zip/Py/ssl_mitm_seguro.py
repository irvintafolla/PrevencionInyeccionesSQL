import requests

url = "https://example.com"
response = requests.get(url, verify=True)  # ✅ Habilita SSL
print(response.text)
