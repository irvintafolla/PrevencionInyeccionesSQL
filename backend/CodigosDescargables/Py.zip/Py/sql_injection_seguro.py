import sqlite3

usuario = input("Ingrese su usuario: ")

conn = sqlite3.connect("base_de_datos.db")
cursor = conn.cursor()
cursor.execute("SELECT * FROM usuarios WHERE nombre = ?", (usuario,))  # ✅ Usa parámetros en SQL
result = cursor.fetchall()
print(result)
conn.close()
