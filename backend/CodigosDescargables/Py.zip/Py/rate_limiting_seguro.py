from flask import Flask, request
import time

app = Flask(__name__)
requests_log = {}

@app.route("/api/data")
def obtener_datos():
    ip = request.remote_addr
    ahora = time.time()

    # ✅ Limita a 1 petición por segundo
    if ip in requests_log and ahora - requests_log[ip] < 1:
        return "Demasiadas solicitudes. Intenta más tarde.", 429

    requests_log[ip] = ahora
    return "Datos sensibles"

app.run()
