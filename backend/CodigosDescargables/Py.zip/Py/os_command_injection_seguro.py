import os

comando = input("Ingrese un comando seguro: ")

comandos_permitidos = ["ls", "dir", "whoami"]
if comando in comandos_permitidos:
    os.system(comando)  # ✅ Solo ejecuta comandos permitidos
else:
    print("Comando no permitido")
