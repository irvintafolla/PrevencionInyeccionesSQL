from flask import Flask, request
import jwt
import datetime

SECRET_KEY = "supersecreto"

app = Flask(__name__)

def generar_token(usuario):
    payload = {
        "usuario": usuario,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

@app.route("/api/datos")
def obtener_datos():
    token = request.headers.get("Authorization")
    try:
        jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return {"mensaje": "Aquí están tus datos sensibles"}
    except jwt.ExpiredSignatureError:
        return {"error": "Token expirado"}, 401
    except jwt.InvalidTokenError:
        return {"error": "Token inválido"}, 401

app.run()
