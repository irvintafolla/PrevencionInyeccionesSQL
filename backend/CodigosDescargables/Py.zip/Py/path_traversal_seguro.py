import os

filename = input("Ingrese el nombre del archivo: ")

# ✅ Solo permite archivos dentro de un directorio seguro
secure_dir = "/home/user/seguro/"
filepath = os.path.join(secure_dir, os.path.basename(filename))

if os.path.commonprefix([os.path.realpath(filepath), secure_dir]) == secure_dir:
    with open(filepath, "r") as file:
        print(file.read())
else:
    print("Acceso denegado.")
