import os

usuario = input("Ingrese su usuario: ")

usuarios_permitidos = ["admin", "supervisor"]
if usuario in usuarios_permitidos:
    print("Acceso concedido, pero comandos peligrosos restringidos.")
else:
    print("Acceso denegado.")
