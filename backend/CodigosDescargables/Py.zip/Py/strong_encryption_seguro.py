from Crypto.Cipher import AES
import os

clave = os.urandom(32)  # ✅ Clave segura de 256 bits
cipher = AES.new(clave, AES.MODE_GCM)

mensaje = b"mensaje secreto"
cifrado, tag = cipher.encrypt_and_digest(mensaje)
print(cifrado)
