using System;
using System.Security.Cryptography;
using System.Text;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese su contraseña: ");
        string password = Console.ReadLine();

        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            string hash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            Console.WriteLine("Contraseña en hash seguro: " + hash);
        }
    }
}
