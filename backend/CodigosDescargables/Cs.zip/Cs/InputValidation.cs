using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese su email: ");
        string email = Console.ReadLine();

        if (Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
        {
            Console.WriteLine("Email válido.");
        }
        else
        {
            Console.WriteLine("Formato de email no válido.");
        }
    }
}
