using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el nombre del archivo: ");
        string filename = Console.ReadLine();

        string safePath = Path.Combine(@"C:\ArchivosSeguros\", Path.GetFileName(filename));

        if (File.Exists(safePath))
        {
            Console.WriteLine("Archivo encontrado: " + safePath);
        }
        else
        {
            Console.WriteLine("Archivo no encontrado.");
        }
    }
}
