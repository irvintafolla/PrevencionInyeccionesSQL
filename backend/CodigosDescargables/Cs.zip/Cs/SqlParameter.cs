using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese su usuario: ");
        string usuario = Console.ReadLine();

        using (SqlConnection conn = new SqlConnection(Environment.GetEnvironmentVariable("DB_CONNECTION_STRING")))
        {
            conn.Open();
            
            // Usamos parámetros en SQL para evitar SQL Injection
            string query = "SELECT * FROM usuarios WHERE nombre = @usuario";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@usuario", usuario);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("Usuario encontrado: " + reader["nombre"]);
            }
        }
    }
}
