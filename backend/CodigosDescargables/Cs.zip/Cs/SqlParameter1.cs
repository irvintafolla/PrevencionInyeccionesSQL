using System;
using System.Data.SqlClient;

class program
{
    static void Main()
    {
        Console.Write("Ingrese su usuario: ");
        string usuario = Console.ReadLine();

        using (SqlConnection conn = new SqlConnection("Data Source=servidor;Initial Catalog=miDB;Integrated Security=True"))
        {
            conn.Open();
            string query = "SELECT * FROM usuarios WHERE nombre = @usuario";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@usuario", usuario);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("Usuario encontrado: " + reader["nombre"]);
            }
            reader.Close();
        }
    }
}