using System;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        HttpClientHandler handler = new HttpClientHandler();
        handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) =>
        {
            return sslPolicyErrors == SslPolicyErrors.None;
        };

        using (HttpClient client = new HttpClient(handler))
        {
            HttpResponseMessage response = await client.GetAsync("https://example.com");
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine("Respuesta segura: " + content);
        }
    }
}
