using System;
using Microsoft.Extensions.Configuration;

class Program
{
    static void Main()
    {
        var config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();

        string dbPassword = config["Database:Password"];
        Console.WriteLine("Conectando con contraseña segura...");
    }
}
