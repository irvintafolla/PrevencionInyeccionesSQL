using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

[Serializable]
class Usuario
{
    public string Nombre { get; set; }
}

class Program
{
    static void Main()
    {
        IFormatter formatter = new BinaryFormatter();
        using (FileStream stream = new FileStream("usuario.dat", FileMode.Open))
        {
            Usuario usuario = (Usuario)formatter.Deserialize(stream);
            Console.WriteLine("Usuario deserializado: " + usuario.Nombre);
        }
    }
}
