using Microsoft.AspNetCore.Identity;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        var userManager = new UserManager<IdentityUser>(null, null, null, null, null, null, null, null, null);

        string username = "usuarioSeguro";
        string password = "P@ssw0rd!";

        var user = new IdentityUser { UserName = username };
        IdentityResult result = await userManager.CreateAsync(user, password);

        Console.WriteLine(result.Succeeded ? "Usuario creado correctamente." : "Error al crear usuario.");
    }
}
