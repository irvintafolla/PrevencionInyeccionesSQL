using System;
using System.Web;

class Program
{
    static void Main()
    {
        string input = "<script>alert('XSS')</script>";
        string sanitizedInput = HttpUtility.HtmlEncode(input);
        Console.WriteLine("Entrada segura: " + sanitizedInput);
    }
}
