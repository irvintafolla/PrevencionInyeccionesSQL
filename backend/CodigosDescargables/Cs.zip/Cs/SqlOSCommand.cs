using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese el comando: ");
        string comando = Console.ReadLine();

        if (comando == "dir" || comando == "ipconfig")
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/C " + comando);
            psi.RedirectStandardOutput = true;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            
            Process process = Process.Start(psi);
            Console.WriteLine("Ejecutando comando de forma segura...");
        }
        else
        {
            Console.WriteLine("Comando no permitido.");
        }
    }
}
