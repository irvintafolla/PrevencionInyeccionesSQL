using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

class Program
{
    static void Main()
    {
        string texto = "Mensaje seguro";
        byte[] clave = Encoding.UTF8.GetBytes("0123456789ABCDEF0123456789ABCDEF"); 
        byte[] iv = Encoding.UTF8.GetBytes("ABCDEF0123456789");

        using (Aes aes = Aes.Create())
        {
            aes.Key = clave;
            aes.IV = iv;

            using (MemoryStream ms = new MemoryStream())
            using (CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
            using (StreamWriter sw = new StreamWriter(cs))
            {
                sw.Write(texto);
            }
            Console.WriteLine("Texto cifrado.");
        }
    }
}
